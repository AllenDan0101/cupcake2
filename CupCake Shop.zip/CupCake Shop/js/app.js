const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const fornecedorRoutes = require('./routes/fornecedorRoutes');
const pageRoutes = require('./routes/pageRoutes'); // Rotas de páginas

const app = express();

// Middleware de logs
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Configurações do servidor
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Servir arquivos estáticos (CSS, imagens, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Configurar as rotas
app.use('/fornecedor', fornecedorRoutes);
app.use('/', pageRoutes); // Rotas de páginas HTML

// Middleware para rotas não encontradas (404)
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
});

// Inicializar o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

// Controle de erros não tratados
process.on('uncaughtException', (err) => {
  console.error('Erro não tratado:', err);
});

process.on('unhandledRejection', (reason) => {
  console.error('Promise rejeitada sem tratamento:', reason);
});
