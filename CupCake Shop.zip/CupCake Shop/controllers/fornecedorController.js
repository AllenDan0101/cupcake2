const Fornecedor = require('../models/fornecedor');

// Cadastrar fornecedor
exports.cadastrarFornecedor = async (req, res) => {
  const { nome, cpfCnpj, endereco, telefone } = req.body;

  if (!nome || !cpfCnpj || !endereco || !telefone) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios!' });
  }

  try {
    const novoFornecedor = await Fornecedor.create({ nome, cpfCnpj, endereco, telefone });
    res.status(201).json(novoFornecedor);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao cadastrar fornecedor: ' + error.message });
  }
};

// Listar fornecedores
exports.listarFornecedores = async (req, res) => {
  try {
    const fornecedores = await Fornecedor.findAll();
    res.status(200).json(fornecedores);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar fornecedores: ' + error.message });
  }
};

// Atualizar fornecedor
exports.atualizarFornecedor = async (req, res) => {
  const { id } = req.params;
  const { nome, cpfCnpj, endereco, telefone } = req.body;

  try {
    const fornecedor = await Fornecedor.findByPk(id);

    if (!fornecedor) {
      return res.status(404).json({ error: 'Fornecedor não encontrado' });
    }

    fornecedor.nome = nome || fornecedor.nome;
    fornecedor.cpfCnpj = cpfCnpj || fornecedor.cpfCnpj;
    fornecedor.endereco = endereco || fornecedor.endereco;
    fornecedor.telefone = telefone || fornecedor.telefone;

    await fornecedor.save();
    res.status(200).json(fornecedor);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar fornecedor: ' + error.message });
  }
};

// Excluir fornecedor
exports.excluirFornecedor = async (req, res) => {
  const { id } = req.params;

  try {
    const fornecedor = await Fornecedor.findByPk(id);

    if (!fornecedor) {
      return res.status(404).json({ error: 'Fornecedor não encontrado' });
    }

    await fornecedor.destroy();
    res.status(200).json({ message: 'Fornecedor excluído com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir fornecedor: ' + error.message });
  }
};
