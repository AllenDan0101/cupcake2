const express = require('express');
const router = express.Router();
const fornecedorController = require('../controllers/fornecedorController'); // Importando o controlador

// Rota para cadastrar fornecedor
router.post('/cadastrar', fornecedorController.cadastrarFornecedor);

// Rota para listar fornecedores
router.get('/listar', fornecedorController.listarFornecedores);

// Rota para atualizar fornecedor
router.put('/atualizar/:id', fornecedorController.atualizarFornecedor);

// Rota para excluir fornecedor
router.delete('/excluir/:id', fornecedorController.excluirFornecedor);

module.exports = router;
